import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { user } from 'src/app/Model/user';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent {
  constructor() { }
  show:boolean=true;
  http:HttpClient=inject(HttpClient);
  @Output()
  UserDetails:EventEmitter<user>=new EventEmitter<user>();

  submitForm(form:NgForm) {
    this.UserDetails.emit(form.value);
    console.log(form.value );
    this.http.post("https://finalproj-4eec8-default-rtdb.firebaseio.com/user.json",form.value).subscribe(()=>{});
  }
  showsignin(){
    this.show=false;
  }
}
