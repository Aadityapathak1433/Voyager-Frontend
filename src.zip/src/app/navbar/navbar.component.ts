import { Component } from '@angular/core';
import { ScrollService } from '../scroll.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  constructor( private scrollService: ScrollService) { }
  showin:boolean=false;
  showabout:boolean=false;
scrollToSection(sectionId: string): void {
  this.scrollService.scrollToElement(sectionId);
}
showSignin(){
  if(this.showin==false){
    this.showin=true;
  }
  else{
this.showin=false;
}
}
showAboutUs(){
  if(this.showabout==false){
    this.showabout=true;
  }
  else{
this.showabout=false;
}
}
}
