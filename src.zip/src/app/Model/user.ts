export class user{
    constructor(
        public UserName:string,
        public Email:string,
        public phoneNum:number
    ){}
}