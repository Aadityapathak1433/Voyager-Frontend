import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { DestinationComponent } from './destination/destination.component';
import { FooterComponent } from './footer/footer.component';
import { HeroComponent } from './hero/hero.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SearchComponent } from './search/search.component';
import { SelectsImgComponent } from './selects-img/selects-img.component';
import { Router, RouterModule, Routes } from '@angular/router';
import {WeatherComponent} from './weather/weather.component'
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { WeatherService } from 'src/weather.service';
import { AboutComponent } from './about/about.component';
import { CardsComponent } from './search/cards/cards.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { SigninComponent } from './hero/signin/signin.component';
import { SignInComponent } from './navbar/sign-in/sign-in.component';
import { AboutUsComponent } from './navbar/about-us/about-us.component';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' }, 
  { path: 'about', component: AboutComponent },
  { path: 'contact', component: FooterComponent },
];

@NgModule({
  declarations: [
    AppComponent, 
    DestinationComponent,
    FooterComponent,
    HeroComponent,
    NavbarComponent,
    SearchComponent,
    SelectsImgComponent,
    WeatherComponent,
    AboutComponent,
    CardsComponent,
    ContactUsComponent,
    SigninComponent,
    SignInComponent,
    AboutUsComponent
    ],
  imports: [
    BrowserModule, 
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
      ],
  providers: [WeatherService],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})
export class AppModule { }

