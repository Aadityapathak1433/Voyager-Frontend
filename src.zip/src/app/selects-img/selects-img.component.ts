import { Component } from '@angular/core';

@Component({
  selector: 'app-selects-img',
  templateUrl: './selects-img.component.html',
  styleUrls: ['./selects-img.component.css']
})
export class SelectsImgComponent {

}
